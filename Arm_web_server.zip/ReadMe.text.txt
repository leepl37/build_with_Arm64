전광판 웹 서버 (API 호출하면 플레이&스탑&수정&업로드 등의 기능을 구현함).

build 시 target 을 Android 버젼으로 빌드하여 Android 기기 내부에서 실행되게 함.